package com.capgemini.test;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bean.GlobalBean;
import com.capgemini.dao.GlobalDaoImpl;
import com.capgemini.exception.GlobalException;
import com.capgemini.util.DBConnection;

public class DBConnectionTest {
    
	static GlobalDaoImpl daotest;
	static Connection dbCon;
    GlobalBean gb= new GlobalBean();
	@BeforeClass
	public static void initialise() {
		daotest = new GlobalDaoImpl();
		dbCon = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	/**
	 * Test case for Establishing Connection
	 * 
	 * @throws GlobalException
	 **/
	@Test
	public void test() throws GlobalException {
		Connection dbCon = DBConnection.getInstance().getConnection();
		Assert.assertNotNull(dbCon);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daotest = null;
		dbCon = null;
	}
	
	
	

}
