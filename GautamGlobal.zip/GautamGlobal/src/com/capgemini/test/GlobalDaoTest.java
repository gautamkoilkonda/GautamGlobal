package com.capgemini.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.bean.GlobalBean;
import com.capgemini.dao.GlobalDaoImpl;
import com.capgemini.exception.GlobalException;

public class GlobalDaoTest {

	static GlobalDaoImpl dao;
	static GlobalBean global;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new GlobalDaoImpl();
		global = new GlobalBean();
	}

	@Test
	public void testAddDonarDetails() throws GlobalException {

		assertNotNull(dao.addGlobalDetails(global));

	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddDonarDetails1() throws GlobalException {
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addGlobalDetails(global));
	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Test
	public void testAddDonarDetails2() throws GlobalException {

		global.setGlobalName("TestingDataBaseInsertion");
		global.setPhoneNumber("9876543210");
		global.setAddress("whitefield");
		global.setDonationAmount(5000);
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addGlobalDetails(global)) > 1000);

	}

	/********************************************
	 * Test case for retriveAllDetails()
	 ************************************************/
	@Test
	public void testViewAll() throws GlobalException {
		assertNotNull(dao.retriveAllDetails());
	}

	/****************************************************
	 * Test case for viewById()
	 ******************************************************/

	@Test
	public void testById() throws GlobalException {
		assertNotNull(dao.viewGlobalDetails("1010"));
	}

	@Ignore
	@Test
	public void testById1() throws GlobalException {
		assertEquals("TestName", dao.viewGlobalDetails("1010").getGlobalName());
	}

}
