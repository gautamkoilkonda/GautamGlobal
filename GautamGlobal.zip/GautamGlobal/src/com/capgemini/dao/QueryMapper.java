package com.capgemini.dao;

public interface QueryMapper {
	
	public static final String RETRIVE_ALL_QUERY="SELECT global_name,address,phone_number,global_date,global_amount FROM global_details";
	public static final String VIEW_GLOBAL_DETAILS_QUERY="SELECT global_name,address,phone_number,global_date,global_amount FROM global_details WHERE  global_id=?";
	public static final String INSERT_QUERY="INSERT INTO global_details VALUES(globalId_sequence.NEXTVAL,?,?,?,SYSDATE,?)";
	public static final String GLOBALID_QUERY_SEQUENCE="SELECT globalId_sequence.CURRVAL FROM DUAL";
	
	
}
