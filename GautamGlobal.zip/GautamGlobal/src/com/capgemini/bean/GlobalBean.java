package com.capgemini.bean;

import java.util.Date;


public class GlobalBean 
{
	private String globalId;
	private String globalName;
	private String phoneNumber;
	private String address;
	private double donationAmount;
	private Date donationDate;
	
	public String getGlobalId() {
		return globalId;
	}
	public void setGlobalId(String globalId) {
		this.globalId = globalId;
	}
	public String getGlobalName() {
		return globalName;
	}
	public void setGlobalName(String globalName) {
		this.globalName = globalName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getDonationAmount() {
		return donationAmount;
	}
	public void setDonationAmount(double donationAmount) {
		this.donationAmount = donationAmount;
	}
	public Date getDonationDate() {
		return donationDate;
	}
	public void setDonationDate(Date donationDate) {
		this.donationDate = donationDate;
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Printing Global Details \n");
		sb.append("Global Name: " +globalName +"\n");
		sb.append("Global Address: "+ address +"\n");
		sb.append("Phone Number: "+ phoneNumber +"\n");
		sb.append("Donation Amount: "+ donationAmount +"\n");
		sb.append("Donation Date: "+ donationDate);
		return sb.toString();
	}
	

	
}
