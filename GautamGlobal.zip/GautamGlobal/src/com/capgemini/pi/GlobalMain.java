package com.capgemini.pi;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.GlobalBean;
import com.capgemini.exception.GlobalException;
import com.capgemini.service.GlobalServiceImpl;
import com.capgemini.service.IGlobalService;

public class GlobalMain {

	static Scanner sc = new Scanner(System.in);
	static IGlobalService globalService = null;
	static GlobalServiceImpl globalServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		GlobalBean globalBean = null;

		String employeeId = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   ICARE GLOBAL RECRUTMENT TRUST ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Global Employee ");
			System.out.println("2.View Global Employee");
			System.out.println("3.Retrive All");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (globalBean == null) {
						globalBean = populateGlobalBean();
						// System.out.println(employeeBean);
					}

					try {
						globalService = new GlobalServiceImpl();
						employeeId = globalService.addGlobalDetails(globalBean);

						System.out
								.println("Global Employee details  has been successfully registered ");
						System.out.println("Global Employee  ID Is: " + employeeId);

					} catch (GlobalException globalException) {
						logger.error("exception occured", globalException);
						System.out.println("ERROR : "
								+ globalException.getMessage());
					} finally {
						employeeId = null;
						globalService = null;
						globalBean = null;
					}

					break;

				case 2:

					globalServiceImpl = new GlobalServiceImpl();

					System.out.println("Enter numeric employee id:");
					employeeId = sc.next();

					while (true) {
						if (globalServiceImpl.validateGlobalId(employeeId)) {
							break;
						} else {
							System.err
									.println("Please enter numeric employee id only, try again");
							employeeId = sc.next();
						}
					}

					globalBean = getGlobalDetails(employeeId);

					if (globalBean != null) {
						System.out.println("Name             :"
								+ globalBean.getGlobalName());
						System.out.println("Address          :"
								+ globalBean.getAddress());
						System.out.println("Phone Number     :"
								+ globalBean.getPhoneNumber());
						System.out.println("Global Date       :"
								+ globalBean.getDonationDate());
						System.out.println("Donation Amount  :"
								+ globalBean.getDonationAmount());
					} else {
						System.err
								.println("There are no Employee details associated with global id "
										+ employeeId);
					}

					break;

				case 3:

					globalService = new GlobalServiceImpl();
					try {
						List<GlobalBean> employeeList = new ArrayList<GlobalBean>();
						employeeList = globalService.retriveAll();

						if (employeeList != null) {
							Iterator<GlobalBean> i = employeeList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("No Employee, yet.");
						}

					}

					catch (GlobalException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;

				case 4:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given employeeId in
	 * parameter
	 */
	private static GlobalBean getGlobalDetails(String employeeId) {
		GlobalBean globalBean = null;
		globalService = new GlobalServiceImpl();

		try {
			globalBean = globalService.viewGlobalDetails(employeeId);
		} catch (GlobalException donarException) {
			logger.error("exception occured ", donarException);
			System.out.println("ERROR : " + donarException.getMessage());
		}

		globalService = null;
		return globalBean;
	}

	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private static GlobalBean populateGlobalBean() {

		// Reading and setting the values for the employeeBean
		
		GlobalBean globalBean = new GlobalBean();;

		System.out.println("\n Enter Details");

		System.out.println("Enter employee name: ");
		globalBean.setGlobalName(sc.next());

		System.out.println("Enter employee contact: ");
		globalBean.setPhoneNumber(sc.next());

		System.out.println("Enter employee address: ");
		globalBean.setAddress(sc.next());

		System.out.println("Enter donation amount: ");

		try {
			globalBean.setDonationAmount(sc.nextFloat());
		} catch (InputMismatchException inputMismatchException) {
			sc.nextLine();
			System.err
					.println("Please enter a numeric value for EMPLOYEE amount, try again");
			}

		globalServiceImpl = new GlobalServiceImpl();

		try {
			globalServiceImpl.validateGlobal(globalBean);
			return globalBean;
		} catch (GlobalException globalException) {
			logger.error("exception occured", globalException);
			System.err.println("Invalid data:");
			System.err.println(globalException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
