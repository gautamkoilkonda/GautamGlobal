package com.capgemini.exception;

public class GlobalException extends Exception 
{
	private static final long serialVersionUID = 726264577455921591L;

	public GlobalException(String message) 
	{
		
		super(message);
	}
}
