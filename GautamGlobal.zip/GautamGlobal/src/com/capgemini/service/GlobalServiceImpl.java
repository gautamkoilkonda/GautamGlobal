package com.capgemini.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bean.GlobalBean;
import com.capgemini.dao.GlobalDaoImpl;
import com.capgemini.dao.IGlobalDAO;
import com.capgemini.exception.GlobalException;

public class GlobalServiceImpl implements IGlobalService {
	
	IGlobalDAO globalDao;
	
	//------------------------ 1. Global Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addGlobalDetails
	 - Input Parameters	:	global object
	 - Return Type		:	String id
	 - Throws			:  	GlobalException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/11/2016
	 - Description		:	adding global to database calls dao method addGlobalDetails(global)
	 ********************************************************************************************************/
	public String addGlobalDetails(GlobalBean global) throws GlobalException {
		globalDao=new GlobalDaoImpl();	
		String globalSeq;
		globalSeq= globalDao.addGlobalDetails(global);
		return globalSeq; 
	}

	//------------------------ 1. Global Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewGlobalDetails
	 - Input Parameters	:	String globalId
	 - Return Type		:	global object
	 - Throws		    :  	GlobalException
	 - Author		    :	CAPGEMINI
	 - Creation Date	:	18/11/2016
	 - Description		:	calls dao method viewGlobalDetails(globalId)
	 ********************************************************************************************************/
	public GlobalBean viewGlobalDetails(String globalId) throws GlobalException {
		globalDao=new GlobalDaoImpl();
		GlobalBean bean=null;
		bean=globalDao.viewGlobalDetails(globalId);
		return bean;
	}

	//------------------------ 1. Global Application --------------------------
	/*******************************************************************************************************
	 - Function Name	: retriveAll()
	 - Input Parameters	:	
	 - Return Type		: list
	 - Throws		    : GlobalException
	 - Author	      	: CAPGEMINI 
	 - Creation Date	: 18/11/2016
	 - Description		: calls dao method retriveAllDetails()
	 ********************************************************************************************************/
	public List<GlobalBean> retriveAll() throws GlobalException {
		globalDao=new GlobalDaoImpl();
		List<GlobalBean> globalList=null;
		globalList=globalDao.retriveAllDetails();
		return globalList;
	}
	
	
	/*******************************************************************************************************
	 - Function Name	: validateGlobal(GlobalBean bean)
	 - Input Parameters	: GlobalBean bean
	 - Return Type		: void
	 - Throws		    : GlobalException
	 - Author	      	: CAPGEMINI
	 - Creation Date	: 18/11/2016
	 - Description		: validates the GlobalBean object
	 ********************************************************************************************************/
	public void validateGlobal(GlobalBean bean) throws GlobalException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating global name
		if(!(isValidName(bean.getGlobalName()))) {
			validationErrors.add("\n Donar Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		//Validating address
		if(!(isValidAddress(bean.getAddress()))){
			validationErrors.add("\n Address Should Be Greater Than 5 Characters \n");
		}
		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getPhoneNumber()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		//Validating Donation Amount
		if(!(isValidAmount(bean.getDonationAmount()))){
			validationErrors.add("\n Amount Should be a positive Number \n" );
		}
		
		if(!validationErrors.isEmpty())
			throw new GlobalException(validationErrors +"");
	}

	public boolean isValidName(String globalName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(globalName);
		return nameMatcher.matches();
	}
	public boolean isValidAddress(String address){
		return (address.length() > 6);
	}
	
	public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		
	}
	public boolean isValidAmount(double amount){
		return (amount>0);
	}
	public boolean validateGlobalId(String globalId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(globalId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
}

	
	


