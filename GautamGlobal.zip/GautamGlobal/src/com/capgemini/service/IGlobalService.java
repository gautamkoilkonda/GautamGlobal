package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.GlobalBean;
import com.capgemini.exception.GlobalException;

public interface IGlobalService 
{
	public String addGlobalDetails(GlobalBean global) throws GlobalException;
	public GlobalBean viewGlobalDetails(String globalId) throws GlobalException;
	public List<GlobalBean> retriveAll()throws GlobalException;
}
